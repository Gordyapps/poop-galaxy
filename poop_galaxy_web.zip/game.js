const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

ctx.fillStyle = 'white';
ctx.font = '30px Comic Sans MS';
ctx.fillText('Welcome to Poop Galaxy!', 200, 300);
